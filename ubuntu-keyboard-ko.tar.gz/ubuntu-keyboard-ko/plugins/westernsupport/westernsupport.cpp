#include "westernsupport.h"


Westernsupport::Westernsupport()
{
}
