#ifndef WESTERNSUPPORT_H
#define WESTERNSUPPORT_H

#include "westernsupport_global.h"

class WESTERNSUPPORTSHARED_EXPORT Westernsupport
{
    
public:
    Westernsupport();
};

#endif // WESTERNSUPPORT_H
