#include "koreanplugin.h"
#include "koreanlanguagefeatures.h"

#include <QDebug>

KoreanPlugin::KoreanPlugin(QObject *parent) :
    QObject(parent)
  , m_languageFeatures(new KoreanLanguageFeatures)
{
}

KoreanPlugin::~KoreanPlugin()
{
}

void KoreanPlugin::parse(const QString& surroundingLeft, const QString& preedit)
{
    Q_UNUSED(surroundingLeft);
    Q_UNUSED(preedit);
}

QStringList KoreanPlugin::getWordCandidates()
{
    QStringList list;

    return list;
}

void KoreanPlugin::wordCandidateSelected(QString word)
{
    Q_UNUSED(word);
}

AbstractLanguageFeatures* KoreanPlugin::languageFeature()
{
    return m_languageFeatures;
}
