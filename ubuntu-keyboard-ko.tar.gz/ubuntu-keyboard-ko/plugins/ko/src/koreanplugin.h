#ifndef KOREANPLUGIN_H
#define KOREANPLUGIN_H

#include <QObject>
#include "languageplugininterface.h"
#include "koreanlanguagefeatures.h"

#include <QObject>

class KoreanLanguageFeatures;

class KoreanPlugin : public QObject, public LanguagePluginInterface
{
    Q_OBJECT
    Q_INTERFACES(LanguagePluginInterface)
    Q_PLUGIN_METADATA(IID "org.qt-project.Qt.Examples.KoreanPlugin" FILE "koreanplugin.json")

public:
    explicit KoreanPlugin(QObject* parent = 0);
    virtual ~KoreanPlugin();

    virtual void parse(const QString& surroundingLeft, const QString& preedit);
    virtual QStringList getWordCandidates();
    virtual void wordCandidateSelected(QString word);
    virtual AbstractLanguageFeatures* languageFeature();

    //! spell checker
    virtual bool spellCheckerEnabled() { return false; }
    virtual bool setSpellCheckerEnabled(bool enabled) { Q_UNUSED(enabled); return false; }
    virtual bool spell(const QString& word) { Q_UNUSED(word); return false; }
    virtual QStringList spellCheckerSuggest(const QString& word, int limit) { Q_UNUSED(word); Q_UNUSED(limit); return QStringList(); }
    virtual void addToSpellCheckerUserWordList(const QString& word) { Q_UNUSED(word); }
    virtual bool setSpellCheckerLanguage(const QString& languageId) { Q_UNUSED(languageId); return false; }

signals:

public slots:

protected:
private:
    KoreanLanguageFeatures* m_languageFeatures;
};

#endif // KOREANPLUGIN_H
